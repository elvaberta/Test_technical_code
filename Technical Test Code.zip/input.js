function inputFunction(){
    var input = document.getElementById("userInput");
}