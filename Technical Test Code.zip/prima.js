let data = inputFunction();
let prima = [];
function primaFunction(){
    inputFunction() = document.getElementById("userInput").value;

    for(let i=inputFunction(); i++;){
        let bilangan = inputFunction();
        for(let a=1; a++;){
            if(a%1 == 0){
                bilangan = bilangan+1;
            }
        }
        if (bil == 2);
            prima = [...prima, i];
    }
}
console.log(prima);