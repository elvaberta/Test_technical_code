function segitigaFunction(t){
    for (i=0; i<=t; i++){
        let eachLine = ''

        for (let j=1; j<=i; j++){
            eachLine += j + " "
        }
        eachLine = eachLine.trim();
        console.log(eachLine);
    }
}
let t = inputFunction();
drawTriangle(t);