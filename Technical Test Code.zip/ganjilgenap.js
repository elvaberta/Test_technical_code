let data = inputFunction();
let ganjil = [];
let genap = [];
function ganjilgenapFunction(){
    inputFunction = document.getElementById("userInput").value;

    for(let i=inputFunction; i++;){
        if(i%2 == 0){
        genap = [...genap, i];
    }else{
        ganjil = [...ganjil,i];
        }
    }
}
console.log({ganjil, genap});